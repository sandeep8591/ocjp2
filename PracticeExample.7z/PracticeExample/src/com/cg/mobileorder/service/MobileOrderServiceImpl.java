package com.cg.mobileorder.service;

import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import com.cg.mobileorder.Exception.MobileException;
import com.cg.mobileorder.bean.Customer;
import com.cg.mobileorder.bean.Mobile;
import com.cg.mobileorder.bean.MobileInfo;
import com.cg.mobileorder.dao.MobileOrderDao;
import com.cg.mobileorder.dao.MobileOrderDaoImpl;

public class MobileOrderServiceImpl implements MobileOrderService {
	
	//object for dao from service
	MobileOrderDao mdao = new MobileOrderDaoImpl();

	@Override
	public int placeorder(Customer customer, Mobile mobile) throws MobileException {
	int c1 = mdao.placeorder(customer, mobile);
		return c1;
	}

	@Override
	public Mobile getPurchaseDetails(int orderId) {
		Mobile m1=mdao.getPurchaseDetails(orderId);
		return m1;
	}

	@Override
	public HashMap<Integer, Customer> fetchallcusdetails() {
		HashMap<Integer, Customer> f= mdao.fetchallcusdetails();
		return f;
	}

	@Override
	public HashMap<String, MobileInfo> mobiledetails() {
		HashMap<String, MobileInfo>m1=mdao.mobiledetails();
		return m1;
	}

	@Override
	public int deletecusbyId(int orderId) {

		int d=mdao.deletecusbyId(orderId);
		return d;
	}


	
	//validations
	
		public static boolean validatecname(String cname)throws MobileException{
			Pattern p=Pattern.compile("[A-Za-z]{1,10}");
			Matcher m=p.matcher(cname);
			if(m.matches()){
				return true;
			}
			return false;
		}
		public static boolean validatecadd(String cadd)throws MobileException{
		Pattern p1=Pattern.compile("[A-Za-z]{1,10}");
		Matcher m1=p1.matcher(cadd);
		if(m1.matches()){
			return true;
		}
		return false;
		}
		public static boolean validateccell(CharSequence ccell)throws MobileException{
			Pattern p=Pattern.compile("[0-9]{10}");
			Matcher m=p.matcher(ccell);
			if(m.matches()){
				return true;
			}
			return false;
		}

		@Override
		public MobileInfo mobileinfo(String mm) {
			MobileInfo m1= mdao.mobileinfo(mm);
			return m1;
		
		}

		@Override
		public Customer searchcusbyid(int cid) {
			Customer c1=mdao.searchcusbyid( cid);
			return c1;
		
		}

		@Override
		public MobileInfo searchmodelbyname(String mname) {
			MobileInfo m1=mdao.searchmodelbyname(mname) ;
			return m1;
		}

		@Override
		public List<MobileInfo> sortmobilebyName() {
			List<MobileInfo> e=mdao.sortmobilebyName();
			return e;
		
		}

		@Override
		public List<MobileInfo> sortmobilebyprice() {
			List<MobileInfo> e1=mdao.sortmobilebyprice();
			return e1;
		}

	

	
	


		
	


}
