package com.cg.mobileorder.ui;


import java.time.LocalDate;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import java.util.Map.Entry;


import com.cg.mobileorder.Exception.MobileException;
import com.cg.mobileorder.bean.Customer;
import com.cg.mobileorder.bean.Mobile;
import com.cg.mobileorder.bean.MobileInfo;
import com.cg.mobileorder.service.MobileOrderService;
import com.cg.mobileorder.service.MobileOrderServiceImpl;


public class RunMain {
	
	//object for scanner and service
	static Scanner sc =null;
	static MobileOrderService serv = null;
	

	public static void main(String[] args) throws MobileException {
	
		sc = new Scanner(System.in);
		serv=new MobileOrderServiceImpl();
		
		int choice=0;
		
		System.out.println("Welcome to city of SuperMarket");
		while(true){
			System.out.println("\nEnter Your Choice");
			System.out.println("press 1 to fetch all mobile details available");
			System.out.println("press 2 to place the Mobile order");
			System.out.println("press 3 to get Order details");
			System.out.println("press 4 to fetch all the custmer details");
			System.out.println("press 5 to Search custmer details by id" );
			System.out.println("press 6 to search mobile model by name");
			System.out.println("press 7 to delete the customer details by id");
			System.out.println("press 8 to sort mobile by name");
			System.out.println("press 9 to sort mobile by price");
		
			
		choice = sc.nextInt();
		switch (choice) {
		case 1:
			 mobiledetails();
			break;	
		case 2:	
			placeorder();
			break;
		case 3:
			getPurchaseDetails();
			break;
		case 4:
			 fetchallcusdetails();
			break;
		case 5:
			searchcusbyid();
			break;
		case 6:
			searchmodelbyname();
			break;
		case 7:
			deletecusbyId();
			break;
		case 8:
			sortmobilebyName();
			break;
		case 9:
			sortmobilebyprice();
			
		default:
			break;
		}
	

		}

	}







private static void sortmobilebyprice()
{
	List<MobileInfo> l=serv.sortmobilebyprice();
	System.out.println("sorting of mobile model by price"+l);
			
}







private static void sortmobilebyName() {
	List<MobileInfo> l=serv.sortmobilebyName();
	
	System.out.println("sorting of employee by name");
			Iterator<MobileInfo> i=l.iterator();
			while(i.hasNext())
				{
				System.out.println(i.next());
				}
		
		
	}







private static void searchmodelbyname() {
	System.out.println("enter the mobile u want:");
	String mname =sc.next();
	MobileInfo c =serv.searchmodelbyname(mname);
	System.out.println("searchedmodel:"+c);
	if (c == null) {
		System.out.println("Search not found! try again with availble model");
	}
	}



private static void searchcusbyid() {
	
	System.out.println("Enter Customer id:");
	int cid = sc.nextInt();
	Customer c = serv.searchcusbyid(cid);
	System.out.println("searchedcusbyid:" + c);
	
		
	}








private static void deletecusbyId() {
	System.out.println("Enter the customer Id to to delete employee");
	int id = sc.nextInt();
	int cus=serv.deletecusbyId(id);

	System.out.println("Employee has been removed "+cus);
}
	



private static void fetchallcusdetails() {
	HashMap<Integer, Customer> set = serv.fetchallcusdetails();
	for (HashMap.Entry m : set.entrySet()) {
		System.out.println(m.getKey() + " " + m.getValue());
	}
		
	}



private static void getPurchaseDetails() {

	System.out.println("Enter orderId:");
	int oid = sc.nextInt();
	Mobile m1=serv.getPurchaseDetails(oid);
	System.out.println("order details:" + m1);
		
	}



private static void mobiledetails() 
	{
		HashMap<String,MobileInfo > m=serv.mobiledetails();
		for(Entry<String, MobileInfo> h:m.entrySet())
		{    
		System.out.println(" "+h.getValue());
		}
				
	}
	
private static void placeorder() throws MobileException
	{
	System.out.println("Enter the Customer name:");
	String cname = sc.next();
	try {
		if(MobileOrderServiceImpl.validatecname(cname)) {
			while (true) {
				System.out.println("Enter the Customer Address:");
				String cadd = sc.next();
				try {
					if(MobileOrderServiceImpl.validatecadd(cadd)) {
						while(true) {
							System.out.println("Enter the Customer Number:");
							String ccell = sc.next();
							try {
								if (MobileOrderServiceImpl.validateccell(ccell)) {
									Customer c = new Customer(cname, cadd, ccell);
									

									System.out.println("Enter Mobile Model:");
									String mm = sc.next();
									MobileInfo c1 = serv.mobileinfo(mm);
									System.out.println(c1);
									if (c1 == null) {
										System.out.println("Please choose model from list");
									}
									
									
									//for random id generation
									LocalDate date = LocalDate.now();
									int max = 5000;
									int min = 1;
									int range = max - min + 1;
									int oid = (int) (Math.random() * range) + min;
									int max1 = 25000;
									int min1 = 1;
									int range1 = max1 - min1 + 1;
									int cid = (int) (Math.random() * range1) + min1;
									
									Mobile m = new Mobile(oid, cid, 20000, mm, date);
									/*MobileInfo mi = new MobileInfo(mm, mprice);*/
									int CustomerDetails = serv.placeorder(c, m);
									//System.out.println("Purchased Mobile:" + mm + " and Orderid is:" + oid);
									System.out.println("order id:" + CustomerDetails);
									System.out.println("Customer id:" + m.getCustomerid());
									break;
								}break;
						
					}catch (Exception e)
					{
					break;
						
				}
				}break;
				
			}
		
	}catch (Exception r) {
		break;
		
	}
	}
		
	
	}

	}catch (Exception c) {
	
		
	}
	
}
}