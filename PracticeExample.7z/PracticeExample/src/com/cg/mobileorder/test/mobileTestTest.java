package com.cg.mobileorder.test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;

import com.cg.mobileorder.Exception.MobileException;
import com.cg.mobileorder.bean.Customer;
import com.cg.mobileorder.bean.Mobile;
import com.cg.mobileorder.dao.MobileOrderDao;
import com.cg.mobileorder.dao.MobileOrderDaoImpl;

import junit.framework.Assert;

class mobileTestTest {
	
static MobileOrderDao mob=null;


/*	@Test
	public int placeorder(Customer customer, Mobile mobile) throws MobileException
	{
		mob=new MobileOrderDaoImpl();
		Assert.assertEquals(1111,1001, mob.placeorder ((1111,new Customer("Chetan","Banglore","1111155555"), (new Mobile(1001,1111,15000,"Nokia",LocalDate.of(2019, 04, 15)))));
		return 0;
		
	}*/
	
}
