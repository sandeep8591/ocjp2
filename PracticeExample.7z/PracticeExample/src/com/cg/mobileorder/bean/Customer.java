package com.cg.mobileorder.bean;

public class Customer {
	
	private String custname;
	private	String cusaddress;
	private String phone;
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(String custname, String cusaddress, String phone) {
		super();
		this.custname = custname;
		this.cusaddress = cusaddress;
		this.phone = phone;
	}
	public String getCustname() {
		return custname;
	}
	public void setCustname(String custname) {
		this.custname = custname;
	}
	public String getCusaddress() {
		return cusaddress;
	}
	public void setCusaddress(String cusaddress) {
		this.cusaddress = cusaddress;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	@Override
	public String toString() {
		return "Customer [custname=" + custname + ", cusaddress=" + cusaddress + ", phone=" + phone + "]";
	}
	
	
	

}
