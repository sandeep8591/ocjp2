package com.cg.mobileorder.bean;

import java.util.Comparator;
import java.util.List;





public class MobileInfo implements Comparable<MobileInfo> {
	private String modelname;
	private float totalPrice;
	public MobileInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public MobileInfo(String modelname, float totalPrice) {
		super();
		this.modelname = modelname;
		this.totalPrice = totalPrice;
	}
	public String getModelname() {
		return modelname;
	}
	public void setModelname(String modelname) {
		this.modelname = modelname;
	}
	public float getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(float totalPrice) {
		this.totalPrice = totalPrice;
	}
	@Override
	public String toString() {
		return "MobileInfo [modelname=" + modelname + ", totalPrice=" + totalPrice + "]"+"\n";
	}
	
	//for sorting by name.
	public static Comparator<MobileInfo> getcompname()
	{
		Comparator<MobileInfo> comp=new Comparator<MobileInfo>() {
	@Override
	public int compare(MobileInfo o1,MobileInfo o2) {
		// TODO Auto-generated method stub
		return  o1.modelname.compareTo(o2.modelname);
	}
		};
		return comp;
	}
	
	@Override
	public int compareTo(MobileInfo a) {
		return (int)(this.totalPrice-a.totalPrice);
	}

}
