package com.cg.mobileorder.bean;

import java.time.LocalDate;

public class Mobile {
	
	private int orderid;
	private int customerid;
	private double totalprice;
	private String modelname;
	private LocalDate date;
	public Mobile() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Mobile(int orderid, int customerid, double totalprice, String modelname, LocalDate date) {
		super();
		this.orderid = orderid;
		this.customerid = customerid;
		this.totalprice = totalprice;
		this.modelname = modelname;
		this.date = date;
	}
	public int getOrderid() {
		return orderid;
	}
	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}
	public int getCustomerid() {
		return customerid;
	}
	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}
	public double getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(double totalprice) {
		this.totalprice = totalprice;
	}
	public String getModelname() {
		return modelname;
	}
	public void setModelname(String modelname) {
		this.modelname = modelname;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "Mobile [orderid=" + orderid + ", customerid=" + customerid + ", totalprice=" + totalprice
				+ ", modelname=" + modelname + ", date=" + date + "]";
	}
	
	
	

}
