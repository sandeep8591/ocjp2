package com.cg.mobileorder.dao;

import java.util.HashMap;
import java.util.List;


import com.cg.mobileorder.Exception.MobileException;
import com.cg.mobileorder.bean.Customer;
import com.cg.mobileorder.bean.Mobile;
import com.cg.mobileorder.bean.MobileInfo;
import com.cg.mobileorder.collectionUtil.CollectionUtil;
import com.cg.mobileorder.service.MobileOrderService;

public class MobileOrderDaoImpl implements MobileOrderDao {
	


	@Override
	public int placeorder(Customer customer, Mobile mobile) throws MobileException {
		int c1=CollectionUtil.purchaseModel(customer,mobile);
		return c1;
	
	}

	@Override
	public Mobile getPurchaseDetails(int orderId) {
		Mobile m1 =CollectionUtil.getPurchaseDetails(orderId);
		return m1;
	}

	@Override
	public HashMap<Integer, Customer> fetchallcusdetails() {
		HashMap<Integer, Customer> f=CollectionUtil.fetchallcusdetails();
		return f;
	}

	@Override
	public HashMap<String, MobileInfo> mobiledetails() {
		HashMap<String, MobileInfo>m1=CollectionUtil.mobiledetails();
		return m1;
	}

	@Override
	public int deletecusbyId(int orderId) {
		int d=CollectionUtil.deletecusbyId(orderId);
		return d;
	}



	@Override
	public MobileInfo mobileinfo(String mm) {
		MobileInfo m1= CollectionUtil.mobileinfo(mm);
		return m1; 
	}

	@Override
	public Customer searchcusbyid(int cid) {
		Customer c1=CollectionUtil.searchcusbyid( cid);
		return c1;
	}

	@Override
	public MobileInfo searchmodelbyname(String mname) {
		MobileInfo m1=CollectionUtil.searchmodelbyname(mname); 
		return m1;
	}


	@Override
	public List<MobileInfo> sortmobilebyName() {
		List<MobileInfo> e=CollectionUtil.sortmobilebyName();
		return e;
		
	}

	@Override
	public List<MobileInfo> sortmobilebyprice() {
		List<MobileInfo> e2=CollectionUtil.sortmobilebyprice();
		return e2;
	}





	

	
	}

	
