package com.cg.mobileorder.dao;

import java.util.HashMap;
import java.util.List;

import com.cg.mobileorder.Exception.MobileException;
import com.cg.mobileorder.bean.Customer;
import com.cg.mobileorder.bean.Mobile;
import com.cg.mobileorder.bean.MobileInfo;
import com.cg.mobileorder.collectionUtil.CollectionUtil;

public interface MobileOrderDao {
	

	
	
	public int placeorder(Customer customer, Mobile mobile) throws MobileException;
	
	public Mobile getPurchaseDetails(int orderId);
	
	public HashMap<Integer, Customer> fetchallcusdetails();
	
	public HashMap<String, MobileInfo> mobiledetails();
	
	public int deletecusbyId(int orderId);
	
	
	
	public MobileInfo mobileinfo(String mm);


	public Customer searchcusbyid(int cid);

	public MobileInfo searchmodelbyname(String mname);



	public List<MobileInfo> sortmobilebyName();


	public List<MobileInfo> sortmobilebyprice();


}


