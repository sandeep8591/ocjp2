package com.cg.mobileorder.collectionUtil;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

import com.cg.mobileorder.bean.Customer;
import com.cg.mobileorder.bean.Mobile;
import com.cg.mobileorder.bean.MobileInfo;

public class CollectionUtil implements Comparator<MobileInfo>{
	
	private static HashMap<String, MobileInfo> hm1=new HashMap<>();
	
	private static HashMap<Integer, Mobile> hm =new HashMap<>();
	
	private static HashMap<Integer, Customer> hc =new HashMap<>();
	

static {
	
	hm.put(1001, new Mobile(1001,1111,15000,"Nokia",LocalDate.of(2019, 04, 15)));	
	hm.put(1002, new Mobile(1002,1112,25000,"Mi",LocalDate.of(2019, 04, 16)));	
	hm.put(1003, new Mobile(1004,1113,35000,"Samsung",LocalDate.of(2019, 04, 17)));	
	hm.put(1004, new Mobile(1005,1114,45000,"Moto",LocalDate.of(2019, 04, 18)));	
	hm.put(1005, new Mobile(1006,1115,55000,"LG",LocalDate.of(2019, 04, 19)));	
	

	hc.put(1111,new Customer("Chetan","Banglore","1111155555"));
	hc.put(1112,new Customer("kiran","pune","1111155556"));
	hc.put(1113,new Customer("manish","madras","1111155557"));
	hc.put(1114,new Customer("pooja","chennai","1111155558"));
	hc.put(1115,new Customer("laxmi","jammu","1111155559"));
	

	hm1.put("Nokia", new MobileInfo("Nokia",2100));
	hm1.put("Mi", new MobileInfo("Mi",22000));
	hm1.put("Samsung", new MobileInfo("Samsung", 23000));
	hm1.put("Moto", new MobileInfo("Moto", 24000));
	hm1.put("LG", new MobileInfo("LG", 25000));
	
	
	 }

private static List<MobileInfo> list=new ArrayList<MobileInfo>();
static 
{
	list.add(new MobileInfo("Nokia",21000));
	list.add(new MobileInfo("Mi", 22000));
	list.add(new MobileInfo("Samsung", 23000));
	list.add(new MobileInfo("Nokia",21000));
	list.add(new MobileInfo("LG", 25000));
}


public static HashMap<String, MobileInfo> mobiledetails() {
	
	return hm1;
}


public static int purchaseModel(Customer customer, Mobile mobile) {
	hc.put(mobile.getCustomerid(), customer);
	hm.put(mobile.getOrderid(), mobile);
	return mobile.getOrderid();
}





public static MobileInfo mobileinfo(String mm) {
	MobileInfo m1=hm1.get(mm);
	return m1;

}


public static Mobile getPurchaseDetails(int orderid) {
	Mobile m1=hm.get(orderid);
	return m1;

}


public static HashMap<Integer, Customer> fetchallcusdetails() {
	{
		return hc;
	
	}
}

public static int deletecusbyId(int orderid) {
	hc.remove(orderid);
	System.out.println("After deletion:"+hc);
	return orderid;
}





public static Customer searchcusbyid(int cid)
{
	return hc.get(cid);
	
}


public static MobileInfo searchmodelbyname(String mname) {
	
	return hm1.get(mname);
}




public static List<MobileInfo> sortmobilebyName()
{
	{
		Collection<MobileInfo> v=hm1.values();
		Collections.sort(list, MobileInfo.getcompname());
	   return list;

	}

}


public static List<MobileInfo> sortmobilebyprice() 
{
	Collections.sort(list);
   return list;
}


@Override
public int compare(MobileInfo o1, MobileInfo o2) {
	
	return 0;
}





}


