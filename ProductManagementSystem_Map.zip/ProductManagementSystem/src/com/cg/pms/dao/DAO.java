package com.cg.pms.dao;

import java.util.List;
import java.util.Map;

import com.cg.pms.bean.Product;
import com.cg.pms.util.Products;

public class DAO implements IDAO {

	@Override
	public Map<Integer,Product> displayAll() {

		return Products.productMap;
	}

	@Override
	public Product searchProduct(int prodId) {

		Product p=null;;
		for(Product temp:Products.productMap.values()) {
			if(temp.getId()==prodId)
				p=temp;
		}
		return p;
	}

	@Override
	public Product removeProduct(int prodId) {
		
		Product p=null;
		
		for(Product temp:Products.productMap.values()) {
			if(temp.getId()==prodId) {
				p=temp;
			}
		}
		Products.productMap.remove(p);
		
		return p;
	}

}
