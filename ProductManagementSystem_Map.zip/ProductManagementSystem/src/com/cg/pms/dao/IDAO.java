package com.cg.pms.dao;

import java.util.List;
import java.util.Map;

import com.cg.pms.bean.Product;

public interface IDAO {

	public Map<Integer,Product> displayAll();

	public Product searchProduct(int prodId);

	public Product removeProduct(int prodId);
}
