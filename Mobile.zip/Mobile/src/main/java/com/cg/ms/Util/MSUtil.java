package com.cg.ms.Util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.cg.ms.Bean.Bill;
import com.cg.ms.Bean.Mobile;

public class MSUtil {

	static Map<Integer, Mobile> mobileMap = new HashMap<Integer, Mobile>();
	// static List<>
	static Map<Integer, Bill> billMap = new HashMap<Integer, Bill>();

	static {
		mobileMap.put(1, new Mobile(1, "Samsung S1", 15000));
		mobileMap.put(5, new Mobile(5, "Samsung S5", 33000));
		mobileMap.put(4, new Mobile(4, "Samsung S4", 12000));
		mobileMap.put(2, new Mobile(2, "Samsung S2", 26000));
		mobileMap.put(3, new Mobile(3, "Samsung S3", 10000));
	}

	public static Map<Integer, Mobile> displayMobiles() {
		return mobileMap;
	}

	public static Map<Integer, Mobile> displayAllMobiles() {
		return mobileMap;
	}

	public static void storeInBillMap(Bill bill) {
		billMap.put(bill.getOrderId(), bill);

	}

	public static Bill displayBill(int orderId) {
		return billMap.get(orderId);
	}

	public static void removeMobile(int id) {
		mobileMap.remove(id);
	}

	public static ArrayList<Mobile> sortOnPrice() {
		ArrayList<Mobile> entryList = new ArrayList<Mobile>(mobileMap.values());
		Collections.sort(entryList, Mobile.priceComparator);
		return entryList;
	}

	public static ArrayList<Mobile> sortOnModelNumber() {
		ArrayList<Mobile> entryList = new ArrayList<Mobile>(mobileMap.values());
		Collections.sort(entryList, Mobile.idComparator);
		return entryList;
	}

	public static ArrayList<Mobile> sortOnModel() {
		ArrayList<Mobile> entryList = new ArrayList<Mobile>(mobileMap.values());
		Collections.sort(entryList, Mobile.modelComparator);
		return entryList;
	}
}
