package com.cg.ms.DAO;

import java.util.ArrayList;
import java.util.Map;

import com.cg.ms.Bean.Bill;
import com.cg.ms.Bean.Mobile;

public interface DAO {
	Map<Integer, Mobile> displayAll();

	Bill searchByID(int orderId);

	void deleteMobile(int mobileId);

	ArrayList<Mobile>  sortOnId();

	ArrayList<Mobile> sortOnName();

	ArrayList<Mobile> sortOnPrice();
}
