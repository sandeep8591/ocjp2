package com.cg.ms.DAO;

import java.util.ArrayList;
import java.util.Map;

import com.cg.ms.Bean.Bill;
import com.cg.ms.Bean.Mobile;
import com.cg.ms.Util.MSUtil;

public class DAOImpl implements DAO {

	public Map<Integer, Mobile> displayAll() {
		return MSUtil.displayAllMobiles();
	}

	public Bill searchByID(int orderId) {
		return MSUtil.displayBill(orderId);
	}

	public void deleteMobile(int mobileId) {
		MSUtil.removeMobile(mobileId);
	}

	public ArrayList<Mobile> sortOnId() {
		return MSUtil.sortOnModelNumber();
	}

	public ArrayList<Mobile> sortOnName() {
		return MSUtil.sortOnModel();

	}

	public ArrayList<Mobile> sortOnPrice() {
		return MSUtil.sortOnPrice();

	}

}
