package com.cg.ms.Service;

import java.util.ArrayList;
import java.util.Map;
import java.util.regex.Pattern;

import com.cg.ms.Bean.Bill;
import com.cg.ms.Bean.Mobile;
import com.cg.ms.DAO.DAO;
import com.cg.ms.DAO.DAOImpl;
import com.cg.ms.Exception.MobileException;

public class ServiceImpl implements Service {

	DAO db = new DAOImpl();

	public Map<Integer, Mobile> displayAll() {
		return db.displayAll();
	}

	public Bill searchByID(int orderId) {
		return db.searchByID(orderId);

	}

	public void deleteMobile(int mobileId) {
		db.deleteMobile(mobileId);
	}

	public ArrayList<Mobile> sortOnId() {
		return db.sortOnId();

	}

	public ArrayList<Mobile> sortOnName() {
		return db.sortOnName();

	}

	public ArrayList<Mobile> sortOnPrice() {
		return db.sortOnPrice();

	}
	
	public void validateName(String name) throws MobileException{
		String nameValid = "[A-Za-z]+";
		
		if(Pattern.matches( nameValid,name) == false)
			throw new MobileException("Give Proper name");
			
	}
	
	public void validateModelNumber(int num) throws MobileException{
		String nameValid = "[1-5](1)";
		
		if(Pattern.matches(nameValid,(String.valueOf(num))) == false)
			throw new MobileException("Not Valid, Give Proper model number");
			
	}

}
