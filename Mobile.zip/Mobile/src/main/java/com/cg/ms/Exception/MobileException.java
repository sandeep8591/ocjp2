package com.cg.ms.Exception;

public class MobileException extends Exception {
	public MobileException(String error) {
		super(error);
	}
}
