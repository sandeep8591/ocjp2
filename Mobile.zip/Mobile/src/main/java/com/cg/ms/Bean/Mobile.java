package com.cg.ms.Bean;

import java.util.Comparator;

public class Mobile {
	String modelName;
	int modelNumber;
	double price;

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public int getModelNumber() {
		return modelNumber;
	}

	public void setModelNumber(int modelNumber) {
		this.modelNumber = modelNumber;
	}

	public Mobile() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Mobile(int modelNumber, String modelName, double price) {
		super();
		this.modelName = modelName;
		this.modelNumber = modelNumber;
		this.price = price;
	}

	@Override
	public String toString() {
		return "Mobile [ModelName=" + modelName + ", ModelNumber=" + modelNumber + ", price=" + price + "]";
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public static Comparator<Mobile> idComparator = new Comparator<Mobile>() {
		public int compare(Mobile o1, Mobile o2) {
			long firstId = o1.getModelNumber();
			long secondId = o2.getModelNumber();
			return Long.compare(firstId, secondId);
		}
	};

	public static Comparator<Mobile> modelComparator = new Comparator<Mobile>() {
		public int compare(Mobile o1, Mobile o2) {
			String firstModel = o1.getModelName();
			String secondModel = o2.getModelName();
			return firstModel.compareTo(secondModel);
		}
	};

	public static Comparator<Mobile> priceComparator = new Comparator<Mobile>() {
		public int compare(Mobile o1, Mobile o2) {
			double firstId = o1.getPrice();
			double secondId = o2.getPrice();
			return Double.compare(firstId, secondId);
		}
	};
}
