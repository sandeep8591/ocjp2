package com.cg.ms.UI;

import java.time.LocalDate;
import java.util.Map;
import java.util.Scanner;

import com.cg.ms.Bean.Bill;
import com.cg.ms.Bean.Customer;
import com.cg.ms.Bean.Mobile;
import com.cg.ms.Exception.MobileException;
import com.cg.ms.Service.Service;
import com.cg.ms.Service.ServiceImpl;
import com.cg.ms.Util.MSUtil;

public class Main {
	static Scanner input = new Scanner(System.in);
	static Service service = new ServiceImpl();
	static Map mobMap = service.displayAll();

	public static void main(String[] args) {
		boolean flag = true;
		do {
			System.out.println("Enter Your Choice:");
			System.out.println("1. Purchase Mobile");
			System.out.println("2. Show Bill");
			System.out.println("3. Remove Mobile");
			System.out.println("4. Sort on ID");
			System.out.println("5. sort on Model");
			System.out.println("6. Sort On Price");
			int choice = input.nextInt();
			input.nextLine();

			switch (choice) {
			case 1:
				purchaseMobile();
				break;
			case 2:
				getBill();
				break;
			case 3:
				removeMobile();
				break;
			case 4:
				sortOnId();
				break;
			case 5:
				sortOnModel();
				break;
			case 6:
				sortOnPrice();
				break;
			default:
				break;
			}

		} while (flag);
	}

	private static void sortOnPrice() {
		// System.out.println(MSUtil.sortOnPrice());
		System.out.println(service.sortOnPrice());
	}

	private static void sortOnModel() {
		System.out.println(service.sortOnName());
	}

	private static void sortOnId() {
		System.out.println(service.sortOnId());
		// (MSUtil.sortOnModelNumber());
	}

	private static void removeMobile() {
		System.out.println("Enter Mobile to be removed");
		int mobileId = input.nextInt();
		// MSUtil.removeMobile(mobileId);
		service.deleteMobile(mobileId);
	}

	private static void getBill() {
		System.out.println("Enter Order ID:");
		int orderId = input.nextInt();
		// System.out.println(MSUtil.displayBill(orderId));
		System.out.println(service.searchByID(orderId));
	}

	private static void purchaseMobile() {
		
		int id = (int)(Math.random()*((1000-1)+1))+1;
		LocalDate dt = LocalDate.now(); 
		
		String name="";
		boolean nameFlag=false;
		do {
		System.out.println("Enter your Name:");
		
		
		try {
			name = input.nextLine();
			service.validateName(name);
			nameFlag=true;
			break;
		}
		catch(MobileException e)
		{
			nameFlag = false;
			System.err.println(e.getMessage());
		}
	}while(!nameFlag);
		
		boolean cityFlag = false;
		
		String city="";
		do
		{
			
			System.out.println("Enter your city:");
			try{
				city = input.nextLine();
				service.validateName(city);
				cityFlag=true;
				break;
			}
			catch(MobileException e)
			{
				cityFlag = false;
				System.err.println(e.getMessage());
			}
		}while(!cityFlag);	
			
		
		Customer customer = new Customer(id, name, city);
		
		System.out.println(MSUtil.displayAllMobiles());
		
		System.out.println("Select Model Number:");
		int modelNumber = 0;
		boolean modelFlag;
		do
		{
			modelFlag = false;
			try
			{
				modelNumber = input.nextInt();
				service.validateModelNumber(modelNumber);
				modelFlag = true;
				break;		
			}
			catch(MobileException e)
			{
				modelFlag = false;
				System.err.println(e.getMessage());
			}
		
		Bill bill = new Bill(id, dt);
		bill.setCustomerId(customer.getCustomerId());
		bill.setCustomerCity(customer.getCustomerCity());
		bill.setCustomerName(customer.getCustomerName());
		
		Mobile mobile = new Mobile();
		if(getMobile(modelNumber) != null)
			mobile = (Mobile) getMobile(modelNumber);
		else
			System.out.println("Wrong option");
		bill.setMobileModel(mobile.getModelName());
		bill.setMobilePrice(mobile.getPrice());
		MSUtil.storeInBillMap(bill);
		System.out.println(bill);
		}while(!modelFlag);
	}

	
	public static Object getMobile(int modelNumber) {
		if(mobMap.containsKey(modelNumber))
			return mobMap.get(modelNumber);
		else
			return null;
			
	}

}
