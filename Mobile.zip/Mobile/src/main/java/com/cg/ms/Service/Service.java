package com.cg.ms.Service;

import java.util.ArrayList;
import java.util.Map;

import com.cg.ms.Bean.Bill;
import com.cg.ms.Bean.Mobile;
import com.cg.ms.Exception.MobileException;

public interface Service {
	Map<Integer, Mobile> displayAll();

	Bill searchByID(int orderID);

	void deleteMobile(int mobileId);

	ArrayList<Mobile> sortOnId();

	ArrayList<Mobile> sortOnName();

	ArrayList<Mobile> sortOnPrice();

	void validateName(String name) throws MobileException;
	void validateModelNumber(int num) throws MobileException;
}
