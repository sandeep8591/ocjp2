package com.cg.ms.Bean;

import java.time.LocalDate;
import java.util.Date;

public class Bill extends Customer {
	private int orderId;
	private String mobileModel;
	private double mobilePrice;

	public String getMobileModel() {
		return mobileModel;
	}

	public void setMobileModel(String mobileModel) {
		this.mobileModel = mobileModel;
	}

	public double getMobilePrice() {
		return mobilePrice;
	}

	public void setMobilePrice(double mobilePrice) {
		this.mobilePrice = mobilePrice;
	}

	public Bill() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Bill(String customerName, int customerId, String customerCity) {
		super(customerId, customerName, customerCity);
		// TODO Auto-generated constructor stub
	}

	public Bill(int orderId, LocalDate dt2) {
		super();
		this.orderId = orderId;
		this.dt = dt2;
	}

	@Override
	public String toString() {
		return "Bill [orderId=" + orderId + ", dt=" + dt + ", customerName=" + getCustomerName() + ", customerId="
				+ getCustomerId() + ", customerCity=" + getCustomerCity() + ", Model:" + mobileModel + ",Price:"
				+ mobilePrice + "]";
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public LocalDate getDt() {
		return dt;
	}

	public void setDt(LocalDate dt) {
		this.dt = dt;
	}

	LocalDate dt;

}
